# Deprecated V1 REST API Examples

These examples are for Bitget's V1 APIs, the previous generation of their API offering.

If you're building new functionality, you should look at using the V2 APIs via the RestClientV2 class in this SDK. This covers all the newer functionality offered by Bitget's APIs - with significant upgrades on all aspects of their APIs:
https://www.bitget.com/api-doc/common/release-note

The V1 REST clients will remain function until Bitget formally deprecates their V1 API.
